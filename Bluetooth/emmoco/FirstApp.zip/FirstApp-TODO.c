/**** DO NOT EDIT -- this file has been automatically generated from @emmoco.com.FirstApp on 2014-05-20T11:50:16 ****/
/**** protocolLevel = 12, toolsVersion = 12.0.0.201211010336 ****/

#include "FirstApp.h"

#ifdef Em_FirstApp_TODO  /* enables optional inclusion of empty functions */

/* Copy the function skeletons below into your own FirstApp.c source file */

void FirstApp_connectHandler(void) {
    /* TODO: application is now connected */
}

void FirstApp_disconnectHandler(void) {
    /* TODO: application is now disconnected */
}

void FirstApp_data_fetch(FirstApp_data_t* const output) {
    /* TODO: write resource 'data' into 'output' */
}

void FirstApp_data_store(FirstApp_data_t* const input) {
    /* TODO: read resource 'data' from 'input' */
}

#endif  /* dummy file */
