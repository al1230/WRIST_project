#ifndef Em_Types_H_
#define Em_Types_H_

#ifndef EM_NOSTDBOOL
#include <stdbool.h>
#endif

#ifndef EM_NOSTDINT
#include <stdint.h>
#endif

#endif /*Em_Types_H_*/
